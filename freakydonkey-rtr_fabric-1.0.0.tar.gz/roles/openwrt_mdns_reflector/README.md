# openwrt_mdns_reflector (stub)

This role was regenerated in dirty recovery mode after local collection loss.
It is intentionally a no-op placeholder.
